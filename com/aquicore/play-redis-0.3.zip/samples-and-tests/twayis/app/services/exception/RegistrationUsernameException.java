package services.exception;

/**
 * 
 * @author tkral
 */
public class RegistrationUsernameException extends RuntimeException {

	public RegistrationUsernameException(String message) {
		super(message);
	}
}
