package controllers;

import play.Play;
import play.mvc.Before;
import play.mvc.Controller;
import play.mvc.Util;

// From: http://stackoverflow.com/a/9168097/1399884

public class ForceHttps extends Controller {
    private static String herokuHttpsEnabled = Play.configuration.getProperty("herokuhttps", "false");

    /** Called before any request to ensure that HTTPS is used. */
    @Before
    public static void redirectToHttps() {
        setSecure();

        //redirect if it's not secure and in production
        if (!request.secure) {
            if (herokuHttpsEnabled.equals("true")) {
                redirect("https://" + request.host + request.url);
            }
            String httpsPort = (String) Play.configuration.get("https.port");
            if (null != httpsPort) {
                String[] pieces = request.host.split(":");
                redirect("https://" + pieces[0] + ":" + httpsPort + request.url);
            }
        }
    }

    @Util
    public static void setSecure() {
        //if it's not secure, but Heroku has already done the SSL processing then it might actually be secure
        if (!request.secure && request.headers.get("x-forwarded-proto") != null) {
            request.secure = request.headers.get("x-forwarded-proto").values.contains("https");
        }
    }

}