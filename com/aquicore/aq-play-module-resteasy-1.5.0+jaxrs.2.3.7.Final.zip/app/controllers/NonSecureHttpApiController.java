package controllers;

import play.mvc.Before;
import play.mvc.Controller;

public class NonSecureHttpApiController extends Controller {
    @Before
    public static void forbidHttp() {
        if (!request.secure) {
            forbidden("Non-secure HTTP API requests are forbidden. Please use HTTPS.");
        }
    }
}