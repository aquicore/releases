package controllers;

import play.Play;
import play.mvc.Before;
import play.mvc.Controller;

public class NonSecureHttpApiController extends Controller {
    private static String herokuHttpsEnabled = Play.configuration.getProperty("herokuhttps", "false");

    @Before
    public static void forbidHttp() {
        if (!request.secure) {
            if (herokuHttpsEnabled.equals("true")) {
                forbidden("Non-secure HTTP API requests are forbidden. Please use HTTPS.");
            }
        }
    }
}