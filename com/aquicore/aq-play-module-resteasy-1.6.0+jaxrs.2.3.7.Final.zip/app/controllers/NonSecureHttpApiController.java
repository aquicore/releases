package controllers;

import play.Play;
import play.mvc.Before;
import play.mvc.Controller;
import play.mvc.Util;

public class NonSecureHttpApiController extends Controller {
    private static String herokuHttpsEnabled = Play.configuration.getProperty("herokuhttps", "false");

    @Before
    public static void forbidHttp() {
        setSecure();

        if (!request.secure) {
            if (herokuHttpsEnabled.equals("true")) {
                forbidden("Non-secure HTTP API requests are forbidden. Please use HTTPS.");
            }
        }
    }

    @Util
    public static void setSecure() {
        //if it's not secure, but Heroku has already done the SSL processing then it might actually be secure
        if (!request.secure && request.headers.get("x-forwarded-proto") != null) {
            request.secure = request.headers.get("x-forwarded-proto").values.contains("https");
        }
    }
}