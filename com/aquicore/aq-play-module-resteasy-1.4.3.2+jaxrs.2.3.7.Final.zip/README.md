~~All documentation located at http://www.lunatech-labs.com/open-source/resteasy-play-module~~

Mirrored and updated from: https://github.com/lunatech-labs/play-module-resteasy to use Play 1.4.2 `DataParsers` API 

To build:
```play build-module```
